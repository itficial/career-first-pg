<!--Sidebar background-->
        <div id="sidebarbg"></div>
        <!--Sidebar content-->
        <div id="sidebar">

           
           <div class="sidenav">

                <div class="sidebar-widget" style="margin: -1px 0 0 0;">
                    <h5 class="title" style="margin-bottom:0">Navigation</h5>
                </div><!-- End .sidenav-widget -->

                <div class="mainnav">
                    <ul>
                       
                      
						<li> 
							<a href="#"><span class="icon16 icomoon-icon-list"></span>Slider</a>
							<ul class="sub">
								<li><a href="add_slider.php"><span class="icon16 icomoon-icon-file"></span>Add Slider</a></li> 
								<li><a href="view_slider.php"><span class="icon16 icomoon-icon-file"></span>View Slider</a></li>
							</ul>
						</li>
						<li>
							<a href="#"><span class="icon16 icomoon-icon-list"></span>Gallery</a>
							<ul class="sub">
								<li><a href="add_gallery.php"><span class="icon16 icomoon-icon-file"></span>Add Gallery</a></li>
								<li><a href="view_gallery.php"><span class="icon16 icomoon-icon-file"></span>View Gallery</a></li>  
							</ul>                   
						</li>
						
						<li>
							<a href="view_contactus.php"><span class="icon16 icomoon-icon-list"></span>Enquiries</a>
							                  
						</li>
                       <li>
							<a href="#"><span class="icon16 icomoon-icon-list"></span>Other Exam Pattern Docs</a>
                            <ul class="sub">
                                <li><a href="add_exam_pattern_docs.php"><span class="icon16 icomoon-icon-list"></span>Add Exam Pattern Docs</a></li>
                                <li><a href="view_exam_pattern_docs.php"><span class="icon16 icomoon-icon-file"></span>View Exam Pattern Docs</a></li>
                                
                            </ul>
							                 
						</li>
						<li>
                            <a href="#"><span class="icon16 icomoon-icon-list"></span>Previous Papers</a>
                            <ul class="sub">
                                <li><a href="add-last-papers.php"><span class="icon16 icomoon-icon-file"></span>Add Paper</a></li>
                                <li><a href="view_paper.php"><span class="icon16 icomoon-icon-file"></span>View Paper</a></li>
                                <li><a href="view_request.php"><span class="icon16 icomoon-icon-file"></span>View Request</a></li>
                                <li><a href="add_year.php"><span class="icon16 icomoon-icon-file"></span>Add Year</a></li>                                
                                <li><a href="view_year.php"><span class="icon16 icomoon-icon-file"></span>View year</a></li>
                                
                            </ul>
                        </li>
						<li>
                            <a href="#"><span class="icon16 icomoon-icon-list"></span>Count Down</a>
                            <ul class="sub">
                                <li><a href="add_countdown.php"><span class="icon16 icomoon-icon-file"></span>Add Count Down</a></li>                                
                            </ul>
                        </li>
                        <li>
                            <a href="#"><span class="icon16 icomoon-icon-list"></span>Courses</a>
                            <ul class="sub">
                                <li><a href="add_upsc_courses.php"><span class="icon16 icomoon-icon-file"></span>Add UPSC Courses</a></li>
                                <li><a href="add_gpsc_courses.php"><span class="icon16 icomoon-icon-file"></span>Add GPSC Courses</a></li>
                                <li><a href="add_optional_subject.php"><span class="icon16 icomoon-icon-file"></span>Add Optional Subjects</a></li>                                
                                <li><a href="add_test_series.php"><span class="icon16 icomoon-icon-file"></span>Add Test Series</a></li>                                
                                
                            </ul>
                        </li>
			<li>
                            <a href="#"><span class="icon16 icomoon-icon-list"></span>Pointer</a>
                            <ul class="sub">
                                <li><a href="add_pointers.php"><span class="icon16 icomoon-icon-file"></span>Add Pointers</a></li>                                
                            </ul>
                        </li>
                       <li>
                            <a href="#"><span class="icon16 icomoon-icon-list"></span>FAQs</a>
                            <ul class="sub">
                                <li><a href="add_faq.php"><span class="icon16 icomoon-icon-file"></span>Add FAQs</a></li>                                
                            </ul>
                        </li>
                       
                    </ul>
                </div>
          
			</div><!-- End sidenav -->
 
 </div><!-- End #sidebar -->